import streamlit as st
import pandas as pd
import matplotlib as plt

dados = {
    'Data': pd.date_range(start='2022-01-01', end='2022-01-15'),
    'Producao': [10, 15, 12, 12, 29, 18, 25, 30, 22, 28, 14, 25, 33, 25, 31],
}

# Criar DataFrame
df = pd.DataFrame(dados)

# Função principal para criar o dashboard
def main():
   
    st.title('Dashboard de Produção CP Lab') # Título

    
    # Adicione texto e imagens ao seu layout
    st.markdown("## Planta CP Lab 406-1")
    #st.markdown("Este é um exemplo de dashboard para acompanhamento de produção.")
    st.image('https://ip.festo-didactic.com/InfoPortal/CPFactoryLab/data/CP-L-406-1/img/image.md.jpg', caption='Imagem de Ilustração', use_column_width=True)

    st.subheader('Produção ao longo do tempo')
    st.line_chart(df.set_index('Data'))   # Gráfico de Linha
    st.bar_chart(df.set_index('Data'))    #grafico de barra

    # Tabela de Dados
    st.subheader('Dados de Produção')
    st.dataframe(df)

    # Estatísticas Simples
    st.subheader('Estatísticas de Produção')
    st.text(f"Média de Produção: {df['Producao'].mean()}")
    st.text(f"Máximo de Produção: {df['Producao'].max()}")
    st.text(f"Mínimo de Produção: {df['Producao'].min()}")

    df['Tempo_entre_ordens'] = df['Data'].diff()
    tempo_medio = df['Tempo_entre_ordens'].mean()
    st.text(f"Tempo Médio entre Ordens: {tempo_medio}")


# Executar o dashboard
if __name__ == '__main__':
    main()