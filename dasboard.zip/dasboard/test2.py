import streamlit as st
import pandas as pd
import matplotlib as plt

from datetime import datetime

data_unico = '2022-01-01'
#horas = ['8:03', '8:24', '9:13', '9:41', '10:00', '10:22', '11:03', '11:27', '12:32', '13:09','14:22', '15:03', '15:57', '16:52', '17:09']
#quantidades = [10, 15, 12, 12, 29, 18, 25, 30, 22, 28, 14, 25, 33, 25, 31]

horas = ['8:00', '8:40', '09:20', '10:00', '10:50', '11:30']
quantidades = [10, 15, 19, 26, 30, 33 ]

# Convertendo as strings de hora para objetos datetime
df = pd.DataFrame({
    'Data': pd.to_datetime([f"{data_unico} {hora}" for hora in horas]),
    'Producao': quantidades,
})

# Ordenando o DataFrame por data
df = df.sort_values(by='Data')

# Função principal para criar o dashboard
def main():
    st.title('Dashboard de Produção CP Lab')  # Título

    st.markdown("## Planta CP Lab 406-1")
    st.image('https://ip.festo-didactic.com/InfoPortal/CPFactoryLab/data/CP-L-406-1/img/image.md.jpg', caption='Imagem de Ilustração', use_column_width=True)

    st.subheader('Produção ')
    st.line_chart(df.set_index('Data'))  # Gráfico de Linha
    st.bar_chart(df.set_index('Data'))  # Gráfico de Barra

    st.subheader('Dados de Produção')
    st.dataframe(df)

    st.subheader('Métricas')
    st.text(f"Média de Produção: {df['Producao'].mean()}")
    st.text(f"Máximo de Produção: {df['Producao'].max()}")
    st.text(f"Mínimo de Produção: {df['Producao'].min()}")

    # Calcular o tempo entre as ordens em horas
    df['Tempo_entre_ordens'] = df['Data'].diff().dt.total_seconds() / 60  # em horas
    tempo_medio = df['Tempo_entre_ordens'].mean()

    st.text(f"Tempo Médio entre Ordens: {tempo_medio:.2f} minutos")

# Executar o dashboard
if __name__ == '__main__':
    main()
